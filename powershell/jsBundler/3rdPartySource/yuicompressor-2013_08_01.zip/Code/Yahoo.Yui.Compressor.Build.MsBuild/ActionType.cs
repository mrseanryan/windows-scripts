﻿namespace Yahoo.Yui.Compressor.Build
{
    public enum ActionType
    {
        Unknown,
        Css,
        JavaScript
    }
}