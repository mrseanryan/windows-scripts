﻿namespace Yahoo.Yui.Compressor
{
    public enum CompressionType
    {
        Standard = 0,
        None = 1
    }
}