﻿namespace Yahoo.Yui.Compressor
{
    public enum JavaScriptCompressionType
    {
        None,
        YuiStockCompression
    }
}