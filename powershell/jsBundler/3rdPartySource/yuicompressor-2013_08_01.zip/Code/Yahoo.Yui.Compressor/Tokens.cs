﻿namespace Yahoo.Yui.Compressor
{

    public static class Tokens
    {
        public const string PreserveCandidateComment = "___YUICSSMIN_PRESERVE_CANDIDATE_COMMENT_";
        public const string PreservedToken = "___YUICSSMIN_PRESERVED_TOKEN_";
        public const string PseudoClassColon = "___YUICSSMIN_PSEUDOCLASSCOLON___";
    }
}
